<?php include('header.php'); ?>

        <section class="hero-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="text-center p-150">
                            <img width="950" class="mb-30" src="assets/img/gift-title.png" alt=""> <br>
                            <img class="mb-30" src="assets/img/i-gift-card.png" alt=""> <br>
                            <a class="link" target="_blank" href="https://squareup.com/gift/YSB0WWKE3ZXWJ/order"><img src="assets/img/gift-card-link.png" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php include('footer.php'); ?>