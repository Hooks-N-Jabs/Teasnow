<?php include('header.php'); ?>

        <section class="hero-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="hero-content">
                            <div class="catering">
                                <div class="coffee-content">
                                    <h2><img src="assets/img/title-3.png" alt=""></h2>
                                    <h3>BRING TEA SNOW BOBA TO YOUR NEXT PARTY!</h3>
                                    <p class="pj">Enjoy TEA SNOW'S beverages at your next special occasion. Tell us about your plans and let our talented catering coordinators help plan the perfect event! Please contact 480.834.2303 or complete catering form</p>
                                </div>
                                <div class="coffee-form">
                                    <div class="catering-title">
                                        <h2><img src="assets/img/title-4.png" alt=""></h2>
                                        <p>Please complete the form below and our tea & coffee specailist will contact you shortly</p>
                                    </div>
                                    <form action="">
                                        <div class="coffee-s-f">
                                            <label>Name:</label>
                                            <input type="text">
                                        </div>
                                        <div class="coffee-s-f">
                                            <label>Email Address:</label>
                                            <input type="email" name="email">
                                        </div>
                                        <div class="coffee-s-f">
                                            <label>Phone Number:</label>
                                            <input type="text" name="phone-number">
                                        </div>
                                        <div class="coffee-s-f">
                                            <label>Prefer Contact By:</label>
                                            <div class="coffee-s-select">
                                                <div class="coffee-s-select-f">
                                                    <input id="r-1" type="radio" name="contact">
                                                    <label for="r-1">Phone</label>
                                                </div>
                                                <div class="coffee-s-select-f">
                                                    <input id="r-2" type="radio" name="contact">
                                                    <label for="r-2">Email</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="coffee-s-f">
                                            <label>Event Date:</label>
                                            <input type="text" name="event-date">
                                        </div>
                                        <div class="coffee-s-f">
                                            <label>Event Type:</label>
                                            <input type="text" name="event-type">
                                        </div>
                                        <div class="coffee-s-f">
                                            <label>Guest Count:</label>
                                            <input type="text" name="guest-count">
                                        </div>
                                        <div class="coffee-s-f">
                                            <label>Notes:</label>
                                            <textarea cols="30" rows="10" name="notes"></textarea>
                                        </div>
                                        <div class="text-center submit-button">
                                            <button type="submit"><img src="assets/img/submit.png" alt=""></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php include('footer.php'); ?>
