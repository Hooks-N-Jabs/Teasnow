<?php 
    if(isset($_POST['submit'])){
        // $to = "sales@a2zpos.com"; // this is your Email address
        $to = "earnest.hooks@gmail.com";
        $from = $_POST['email']; // this is the sender's Email address
        $first_last = $_POST['first_last'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $eventType = $_POST['event-type']
        $restaurant_name = $_POST['restaurant_name'];
        $subject = "Demo Inquiry from a2zpos.com";
        $subject2 = "Thanks again for inquiring from a2zpos.com";
        
        // To send HTML mail, the Content-type header must be set
        $headers  = 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers = "From:" .$from. "\r\n";
        $headers .= "Reply-To:" .$to."\r\n";
        $headers .= "Return-Path: " .$to. "\r\n";
        $headers .= 'To: '.$to."\r\n";     
        
        // To send HTML mail, the Content-type header must be set
        $headers2  = 'MIME-Version: 1.0' . "\r\n";
        $headers2 .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
        $headers2 = "From:" .$from. "\r\n";
        $headers2 .= "Reply-To:" .$to."\r\n";
        $headers2 .= "Return-Path: " .$to. "\r\n";
        $headers2 .= 'To: '.$to."\r\n";  

        // Compose a simple HTML email message
        $message = '<html><body>';
        $message .= '<p>Hi there,</p>';
        $message .= '<p>Below are details for Demo Inquiry:</p>';
        $message .= '<p>Name: ' . $first_last . '</p>';
        $message .= '<p>Email: ' . $email . '</p>';
        $message .= '<p>Phone: ' . $phone . '</p>';
        $message .= '<p>Restaurant Name: ' . $restaurant_name . '</p>';
        $message .= '</body></html>';

         // Compose a simple HTML email message
        $message2 = '<html><body>';
        $message2 .= '<p>Hi there,</p>';
        $message2 .= '<p>Here is a copy of the details you provided:</p>';
        $message2 .= '<p>Name: ' . $first_last . '</p>';
        $message2 .= '<p>Email: ' . $email . '</p>';
        $message2 .= '<p>Phone: ' . $phone . '</p>';
        $message2 .= '<p>Restaurant Name: ' . $restaurant_name . '</p>';
        $message2 .= '</body></html>';

        mail($to,$subject,$message,$headers);
        mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender
        if ( mail($to,$subject,$message,$headers) ) {
            echo "Mail Sent Successfully. Thank you " . $first_last . ", we will contact you shortly.";
        } else {
         echo "The email has failed!";
        }
                // You can also use header('Location: thank_you.php'); to redirect to another page.
        echo "<script>if ( window.history.replaceState ) {window.history.replaceState( null, null, window.location.href );}</script>";
    }
?>