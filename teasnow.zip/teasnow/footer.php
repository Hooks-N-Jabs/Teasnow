<footer class="footer-area pj color-w">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <p>Copyright &copy; 2020 Tea Snow.</p>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex">
                            <p>FOLLOW US</p>
                            <ul>
                                <li><a href="<?php echo $fbLink?>"><img src="assets/img/fb.png" alt=""></a></li>
                                <li><a href="<?php echo $igLink?>"><img src="assets/img/ig.png" alt=""></a></li>
                            </ul>                           
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <div id="preloader">
            <div class="jumper">
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>  

        <!-- Scripts -->
        <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
        <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-1.11.3.min.js"><\/script>')</script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>