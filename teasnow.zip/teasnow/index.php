<?php include('header.php'); ?>

        <section class="hero-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="hero-content">
                            <div class="hero-product">
                                <div class="single-product">
                                    <div class="product-image">
                                        <img src="assets/img/menu-1.png" alt="">
                                    </div>
                                    <h2>House Cocktail</h2>
                                </div>
                                <div class="single-product">
                                    <div class="product-image">
                                        <img src="assets/img/menu-2.png" alt="">
                                    </div>
                                    <h2>Golden Bubble <br>Milk Tea</h2>
                                </div>
                                <div class="single-product">
                                    <div class="product-image">
                                        <img src="assets/img/menu-1.png" alt="">
                                    </div>
                                    <h2>Five Color <br>Dessert</h2>
                                </div>
                            </div>
                            <div class="hero-right">
                                <img src="assets/img/try_not_attached_to_get_too.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="menu" class="section-area pj color-w p-50">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div id="carouselIndicators" class="carousel slide custom" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselIndicators" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselIndicators" data-slide-to="1"></li>
                                <li data-target="#carouselIndicators" data-slide-to="2"></li>
                                <li data-target="#carouselIndicators" data-slide-to="3"></li>
                                <!-- <li data-target="#carouselIndicators" data-slide-to="4"></li> -->
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="row">
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-1.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Orange Cream</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-2.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Thai Dessert</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-3.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Golden Bubble <br>Milk Tea</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-4.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Red Bean <br>Coconut Cream <br>with Boba</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-5.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Taro <br>Coconut Cream</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-6.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Chamango</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-7.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Five Color <br>Dessert</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-8.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Honey <br>Green Tea <br>with Sea Salt</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-9.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Raspberry <br>Blended</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-10.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Pennywort <br>Juice</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-11.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Cookies N <br>Cream</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-12.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Lychee <br>Strawberry Blended <br>with <br>Strawberry Pops</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="row">
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-13.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Chocolate <br>Blended <br>with Boba</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-14.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Q’s Creation</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-15.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Summer Cold</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-16.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Passion Fruit <br>Blended with <br>Kiwi Pops</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-17.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Paradise</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-18.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Taro Milk Tea <br>with Boba</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-19.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Coco Loco</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-20.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Strawberry <br>Mojoto</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-21.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Fruit Tea</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-22.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Honeydew <br>Blended</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-23.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Sweet & Spicy <br>Watermelon</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-24.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Sunrise</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="row">
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-25.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Sunset</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-26.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Matcha <br>Milk Tea</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-27.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Hula Hula</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-28.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Taro <br>Blended</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-29.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Coconut Cream <br>and <br>Grass Jelly</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-30.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Mixed Berry <br>Blended</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-31.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Mango <br>Blended</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-32.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Coffee <br>Milk Tea</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-33.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Passionfruit <br>Green Tea</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-34.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Caramel <br>Jasmine <br>Milk Tea with <br>Sea Salt <br>Cream</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-35.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>House <br>Cocktail</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-36.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Matcha Blended <br>with <br>Red Bean</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>           
                                </div>
                                <div class="carousel-item">
                                    <div class="row">
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-37.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Pennywort <br>& <br>Coconut Juice</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-38.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Pineapple <br>Blended <br>with Boba</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-39.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Strawberry <br>Blended</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-40.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Smashed <br>Avocado</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-41.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Peach <br>Blended</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-42.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Mango Green Tea <br>with Boba <br>& Mango Bits</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-43.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Vietnamese <br>Coffee <br>with <br>Sea Salt Cream</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-44.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Strawberry <br>Black Tea</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-45.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Lychee Blend with  <br>Strawberry Bits & Pops</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-46.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Blueberry <br>Blend with <br>Blueberry Pops <br>and Jelly</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu arrow">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-47.png" alt="">
                                                    <span>Thai Tea <br>with Boba</span>
                                                    <span>Taro Milk tea <br>with Boba</span>
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Split Cup</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-48.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Pennywort <br>Mungbean <br> with <br>Grass Jelly</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="carousel-item">
                                    <div class="row">
                                        <div class="col-md-6 col-lg-9 order-md-1">
                                            <div class="menu-title">
                                                <img src="assets/img/i-title-1.png" alt="">
                                                <p>Comes in Small, Medium or Large</p>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-0">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-49.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Matcha</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-2">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-50.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Mango</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-2">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-51.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Strawberry</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-2">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-52.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Black Sesame</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-2">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-53.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Vanilla</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-2">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-54.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Taro</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-2">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-55.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Chocolate</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-2">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-56.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Coconut</h2>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-3 order-md-2">
                                            <div class="single-menu">
                                                <div class="menu-image">
                                                    <img src="assets/img/m-57.png" alt="">
                                                </div>
                                                <div class="menu-text">
                                                    <h2>Pistachio</h2>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                            </div>  
                            <a class="carousel-control-prev" href="#carouselIndicators" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselIndicators" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>                          
                    </div>
                </div>
            </div>
        </section>

        <!-- <section class="section-area pj color-w p-50">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <div class="product">
                            <img width="500" class="mb-20" src="assets/img/i-title-2.png" alt="">
                            <p>“Tea Snow Coffee is made daily through traditional methods of a slow drip by drip process of using a phin. We provide Vietnamese Coffee to local markets, restaurants, and events. Wholesale & Individual orders can be accommodated. For pricing, please contact 602.524.3006 or info@teasnow.com”</p>
                            <img class="mt-20" width="500" src="assets/img/p-1.png" alt="">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="gift-card">
                            <p>Gift Card is available for in-store purchase, every day!</p>
                            <img class="mb-20" width="450" src="assets/img/i-gift-card.png" alt="">
                            <div class="gift-box">
                                <h2>BRING TEA SNOW BOBA TO YOUR NEXT PARTY!</h2>
                                <p>Enjoy TEA SNOW'S beverages at your next special occasion. Tell us about your plans and let our talented catering coordinators help plan the perfect event! Please contact 602.524.3006 for more information.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->

        <!-- <section class="section-area pj color-w p-50">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="food-menu">
                            <h2>signature specials</h2>
                            <h3>1.  House Cocktail (24 oz) </h3>
                            <p>Strawberry & mango bits, basil seed, lychee fruit, rainbow & pandan jelly</p>
                            <h3>2.  Basil Seed Grass Jelly (24 oz) <img src="assets/img/icon.png"></h3>
                            <h3>3.  Coconut Cream Grass Jelly (24 oz) <img src="assets/img/icon.png"></h3>
                            <h3>4.  Thai Dessert (24 oz) </h3>
                            <p>Jackfruit, coconut jelly pudding, rainbow jelly, pandan jelly, and coconut cream</p>
                            <h3>5.  Pennywort Mung Bean (20 oz)</h3>
                            <h3>6.  Five Color Dessert (20 oz) </h3>
                            <p>ALL home-cooked taro, mung bean, & red bean with coconut cream topped with  red tapioca & pandan jelly (3 color desert upon request)</p>
                            <h3>7.  Coco Loco (24 oz) </h3>
                            <p>Coconut juice & coconut meat, strawbery bits & mango bits</p>
                            <h3>8.  Sunset (24 oz)  </h3>
                            <p>Passionfruit juice, basil seeds, mango & strawberry</p>
                            <h3>9.  Smashed Avocado (20 oz)</h3>
                            <h3>10. Red Bean Coconut Cream (20 oz)</h3>
                            <h3>11. Pennywort Coconut Juice (24 oz)</h3>
                            <h3>12. Coconut Juice Grass Jelly (24 oz)</h3>
                            <h3>13. Paradise </h3>
                            <p>Coconut juice & coconut meat with basil seed</p>
                            <h3>14. Strawberry Mojito (24 oz) </h3>
                            <p>Fresh strawberry with crushed mint leaves & basil seeds</p>
                            <h3>15. Summer Cold (24 oz) </h3>
                            <p>Fresh watermelon juice, basil seeds, & crystal boba</p>
                            <h3>16. Fruit Tea (24 oz)</h3>
                            <p>Premium green tea infused with fresh fruit</p>
                            <h3>17. Hula Hula (24 oz) </h3>
                            <p>Passionfruit juice with a splash of fresh lime & mint</p>
                            <h3>18. Sunrise (24 oz) </h3>
                            <p>Fresh squeeze OJ with basil seeds & rainbow jelly </p>
                            <h3>19. Coconut Juice Basil Seed </h3>
                            <h3>20. Orange Juice (Fresh Squezed) (20oz)</h3>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="food-menu">
                            <h2 class="color-1">tea <span>(20 oz)</span></h2>
                            <h4>upgrade to large (24 oz) +$0.50</h4>
                            <h3>21. Milk Tea <img src="assets/img/icon.png" alt=""></h3>
                            <h3>22. Thai Tea <img src="assets/img/icon.png" alt=""></h3>
                            <h3>23. Taro Milk Tea <img src="assets/img/icon.png" alt=""></h3>
                            <h3>24. Mango Green Tea  </h3>
                            <h3>25. Strawberry Milk Tea </h3>
                            <h3>26. Mango Milk Tea</h3>
                            <h3>27. Honey Jasmine Tea</h3>
                            <h3>28. Jasmine Milk Tea</h3>
                            <h3>29. Japanese Matcha</h3>
                            <h3>30. Mung Bean Milk Tea </h3>
                            <h3>31. Honeydew Milk Tea</h3>
                            <h3>32. Peach Green Tea</h3>
                            <h3>33. Passion Fruit Green Tea </h3>
                            <h3>34. Raspberry Black Tea</h3>
                            <h3>35. Chai Tea Latte  <img src="assets/img/icon.png" alt=""></h3>
                            <h3>36. Pistachio Milk Tea  </h3>
                            <h3>37. Coffee Milk Tea  <img src="assets/img/icon.png" alt=""></h3>
                            <h3>38. Golden Bubble Milk Tea </h3>
                            <p>Brown sugar boba with fresh milk, layered with sea salt cream & topped with caramelized brown sugar</p>
                            <h3>39. Caramel Jasmine Milk Tea</h3>
                            <h3>40. Royal Milk Tea</h3>
                            <p>Our signature milk tea with boba, grass jelly, & egg pudding</p>
                            <h3>41. Strawberry Black Tea </h3>
                            <h3 class="mb-30">42. Chocolate Milk Tea</h3>
                            <p class="text-center">Split cup available for $5.50 <img src="assets/img/icon.png" alt=""></p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="food-menu">
                            <h2 class="color-2">blended <span>(20 oz)</span></h2>
                            <div class="row">
                                <div class="col-lg-4">
                                    <h3>43. Chamango <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>44. Mango <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>46. Watermelon <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>47. Strawberry <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>48. Avocado <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>49. Strawberry Banana <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>50. Mango Passion <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>51. Taro</h3>
                                    <h3>52. Taro Coconut</h3>
                                    <h3>53. Cookies N Cream</h3>
                                    <p>Blended w/ real Oreo</p>
                                    <h3>54. Banana <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>55. Coconut</h3>
                                    <h3>56. Blueberry <img src="assets/img/icon-1.png" alt=""></h3>
                                </div>
                                <div class="col-lg-4">
                                    <h3>57. Chocolate</h3>
                                    <h3>58. Durian <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>59. Pistachio</h3>
                                    <h3>60. Chai</h3>
                                    <h3>61. Red Bean <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>62. Mango CocoCream <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>63. Spicy Watermelon <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>64. Matcha</h3>
                                    <h3>65. Green Apple</h3>
                                    <h3>66. Honeydew</h3>
                                    <h3>67. Kiwi</h3>
                                    <h3>68. Lychee <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>69. Mix Berry <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>70. Orange Cream</h3>
                                </div>
                                <div class="col-lg-4">
                                    <h3>71. Passion Fruit</h3>
                                    <h3>72. Peach <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>73. Pineapple <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>74. Pina Colada <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>75. Vanilla</h3>
                                    <h3>76. Mocha</h3>
                                    <h3>77. Q’s Creation</h3>
                                    <p>Blended w/ fresh & watermelon & strawberries</p>
                                    <h3>78. Coffee Blended</h3>
                                    <h3>79. Milk Tea</h3>
                                    <h3>80. Thai Tea</h3>
                                    <h3>81. Mung Bean <img src="assets/img/icon-1.png" alt=""></h3>
                                    <h3>82. Raspberry <img src="assets/img/icon-1.png" alt=""></h3>
                                </div>
                            </div>
                            <p class="text-right mt-20">Blended with real fruit <img width="25" src="assets/img/icon-2.png" alt=""></p>
                            <div class="row mt-50">
                                <div class="col-lg-6">
                                    <div class="food-menu">
                                        <h2 class="color-3">Coffee</h2>
                                        <h3>71. Vietnamese Coffee (20oz)</h3>
                                        <p>Slow drip through traditional technique of using a phin</p>
                                        <h3>72. Cold Brew (20oz)</h3>
                                        <p>Vietnamese, vanilla, caramel, mocha, or sweet cream</p>
                                        <h3>73. Mocha</h3>
                                        <h3>74. Latte</h3>
                                        <h3>75. Espresso</h3>
                                        <h3>76. Americano</h3>
                                        <h3>77. Hot Chocolate (16oz)</h3>
                                        <h3>78. Affogato</h3>
                                        <p>Double scoop of ice cream, double expresso shot topped with whipped cream</p>
                                    </div>
                                </div>
                                <div class="col-lg-6 text-center">
                                    <h2 class="color-4">Shaved Snow</h2>
                                    <h5>Flavors: Black Sesame, Chocolate, Coconut, Mango, Matcha, Pistachio,Strawberry, Taro, or Vanilla</h5>
                                    <h3><span class="text-left">Small</span> $4.99</h3>
                                    <h3><span class="text-left">Medium</span> $5.99</h3>
                                    <h3 class="mb-20"><span class="text-left">Large</span> $6.99</h3>
                                    <h5><em>All snow includes 2 toppings</em></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->

        <!-- <section class="section-area pj color-w p-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="contact-box">
                            <h2>About Tea Snow</h2>
                            <h4>Tea Snow & Coffee is a unique beverage and dessert boutique famous for its BOBA &  exotic "Signature Specials".</h4>
                            <p>For over a decade now we have been serving our customers an assortment of teas, blended beverages, and traditional phinned Vietnamese coffee.</p>
                            <p>Our boba-tenders handcraft each drink with the freshest & finest quality ingredients. We hand select the freshest fruits, seep the tea leaves (not brew), import exotic elements from overseas, incorporate organic ingredients, and we home cook daily our puddings, beans, taro, creams, & jellies utilizingtraditional methods with authentic recipes </p>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="contact-text">
                            <h2>Contact Us</h2>
                            <p>At Tea Snow, we strive to provide exceptional customer service. Combined with our old world ethnic recipes, viola.....you now have a 1 of a kind experience you can only find at Tea Snow.</p>
                            <h3>Feel Free to keep in touch with us!</h3>
                            <div class="contact-info">
                                <div class="contact-left">
                                    <p>Mekong Plaza Location <br>66 S Dobson Rd. Ste 150 <br>Mesa, AZ 85202</p>
                                </div>
                                <div class="contact-right">
                                    <ul>
                                        <li><a href="tel:480-834-2303"><span><i class="fa fa-phone" aria-hidden="true"></i></span>480-834-2303</a></li>
                                        <li><a href="mailto:info@teasnow.com"><span><i class="fa fa-envelope" aria-hidden="true"></i></span>info@teasnow.com</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="contact-map">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3330.376992048281!2d-111.87795098565753!3d33.413414458572326!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x872b081439a7a4af%3A0xd441ccbe5a6cd690!2sTea%20Snow%20Boba%20%26%20Coffee!5e0!3m2!1sen!2sbd!4v1603386259843!5m2!1sen!2sbd" width="640" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->

        <?php include('footer.php'); ?>