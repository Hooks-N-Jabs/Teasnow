(function ($) {
    "use strict";

	$(window).on('load', function() {
		$("#preloader").animate({
			'opacity': '0'
		}, 600, function(){
			setTimeout(function(){
				$("#preloader").css("visibility", "hidden").fadeOut();
			}, 300);
		});
	});
    $(document).ready(function($){

    	$('#menu-button.menu-tiggle').on('click', function(){
    		$('body').toggleClass('open-menu');
    	});

		$(window).scroll(function() {    
		    var scroll = $(window).scrollTop();
		    if (scroll >= 50) {
		        $('.header-area').addClass('fixed-box');
		    } else {
		    	$('.header-area').removeClass('fixed-box');
		    }
		});

		var headerHeight = $(".header-area").height();
		
		$('a.scroll[href*=#]:not([href=#])').click(function() {
			if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
				var target = $(this.hash);
				target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
				if (target.length) {
					$('html,body').animate({
						scrollTop: target.offset().top - headerHeight
					}, 1000);
					return false;
				}
			}
		});

    });
    
}(jQuery)); 