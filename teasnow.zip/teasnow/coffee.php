<?php include('header.php'); ?>

        <section class="hero-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="hero-content">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="coffee-content">
                                        <h2><img width="400" src="assets/img/title-1.png" alt=""></h2>
                                        <p class="pj">“Tea Snow Coffee is made daily through traditional methods of a slow drip by drip process of using a phin. We provide Vietnamese Coffee to local markets, restaurants,  and events. Wholesale & Individual orders can be accommodated. For pricing, please contact 480.834.2303 or fill in the form”</p>
                                        <img src="assets/img/p-1.png" alt="">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="coffee-form">
                                        <h2><img src="assets/img/title-2.png" alt=""></h2>
                                        <p>Please complete the form below and our tea & coffee specailist will contact you shortly</p>
                                        <form action="">
                                            <div class="coffee-s-f">
                                                <label>Name:</label>
                                                <input type="text">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Email Address:</label>
                                                <input type="email">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Phone Number:</label>
                                                <input type="text">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Prefer Contact By:</label>
                                                <div class="coffee-s-select">
                                                    <div class="coffee-s-select-f">
                                                        <input id="r-1" type="radio" name="contact">
                                                        <label for="r-1">Phone</label>
                                                    </div>
                                                    <div class="coffee-s-select-f">
                                                        <input id="r-2" type="radio" name="contact">
                                                        <label for="r-2">Email</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Event Date:</label>
                                                <input type="text">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Event Type:</label>
                                                <input type="text">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Guest Count:</label>
                                                <input type="text">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Notes:</label>
                                                <textarea cols="30" rows="10"></textarea>
                                            </div>
                                            <div class="text-center">
                                                <button type="submit"><img src="assets/img/submit.png" alt=""></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    <?php include('footer.php'); ?>
