<?php 
    $oloLink = "https://farebites.com/RestaurantMenu/Menu/33";
    $fbLink = "https://www.facebook.com/TeaSnowBoba/";
    $igLink = "https://www.instagram.com/teasnowboba/";
?>

<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Tea Snow Boba – Simply Amazing!</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Favicon -->
        <link rel="shortcut icon" href="assets/img/favicon/favicon.ico">
        <link rel="apple-touch-icon-precomposed" href="assets/img/favicon/icon.png">   
        
        <!-- Fonts -->
        <link rel="stylesheet" href="assets/webfonts/fonts.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        
        <!-- Styles -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css" media="screen">
        <link rel="stylesheet" href="assets/css/normalize.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
        
        <!-- Mordernizer -->
        <script src="assets/js/vendor/modernizr-3.8.0.min.js"></script>

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>
    <body>

        <header class="header-area fixed-top">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header">
                            <div class="header-left">
                                <div class="logo">
                                    <a href="./"><img src="assets/img/logo.png" alt=""></a>
                                </div>
                                <button id="menu-button" class="menu-tiggle">
                                    <img src="assets/img/menu.png" alt="">
                                </button>
                                <div class="menu">
                                    <div class="main-menu">
                                        <ul>
                                            <li><a class="scroll" href="<?php echo $oloLink; ?>">Menu</a></li>
                                            <li><a href="gift">Gift <br>Card</a></li>
                                            <li><a href="coffee">Coffee <br>To Go</a></li>
                                            <li><a href="catering">Catering</a></li>
                                            <li><a href="franchise">Franchise <br>Opportunity</a></li>
                                            <li><a href="contact">Contact Us</a></li>
                                        </ul>
                                    </div> 
                                    <div class="social-links">
                                        <ul>
                                            <li><a href="<?php echo $fbLink?>"><img src="assets/img/fb.png" alt=""></a></li>
                                            <li><a href="<?php echo $igLink?>"><img src="assets/img/ig.png" alt=""></a></li>
                                        </ul>
                                    </div>                                     
                                </div>
                            </div>
                            <div class="header-right">
                                <a href="<?php echo $oloLink?>"><img src="assets/img/order.png" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>        