<?php include('header.php'); ?>

        <div class="hero-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="hero-content">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="coffee-content">
                                        <h2><img width="500" src="assets/img/title-7.png" alt=""></h2>
                                        <div class="address">
                                            <div class="address-left">
                                                <p>Mekong Plaza Location <br>66 S Dobson Rd. Ste 150 <br>Mesa, AZ 85202</p>
                                            </div>
                                            <div class="address-right">
                                                <ul>
                                                    <li><a href="tel:4808342303"><img src="assets/img/c-icon-1.png" alt="">480.834.2303</a></li>
                                                    <li><a href="mailto:info@teasnow.com"><img src="assets/img/c-icon-2.png" alt="">info@teasnow.com</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="map">
                                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3330.376992048281!2d-111.87795098565753!3d33.413414458572326!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x872b081439a7a4af%3A0xd441ccbe5a6cd690!2sTea%20Snow%20Boba%20%26%20Coffee!5e0!3m2!1sen!2sbd!4v1605333638598!5m2!1sen!2sbd" width="100%" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="coffee-form">
                                        <h2><img src="assets/img/title-6.png" alt=""></h2>
                                        <p>We want our customers to have a great experience every time they visit Tea Snow Boba. If something was not quite right the last time you stopped in for a sip? Please complete the form below and let us know</p>
                                        <form action="">
                                            <div class="coffee-s-f">
                                                <select class="custom-select">
                                                    <option value="">General</option>
                                                    <option value="">Compliment</option>
                                                    <option value="">Complaint</option>
                                                </select>
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Email Address</label>
                                                <input type="email">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Full Name</label>
                                                <input type="text">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Phone Number</label>
                                                <input type="text">
                                            </div>
                                            <div class="coffee-s-f">
                                                <label>Your Message</label>
                                                <textarea></textarea>
                                            </div>
                                            <div class="text-center">
                                                <button type="submit"><img src="assets/img/submit.png" alt=""></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include('footer.php'); ?>
