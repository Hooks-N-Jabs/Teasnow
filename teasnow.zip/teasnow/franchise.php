<?php include('header.php'); ?>

        <section class="hero-area">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="hero-content">
                            <div class="catering">
                                <div class="coffee-content">
                                    <h2><img width="400" src="assets/img/title-5.png" alt=""></h2>
                                    <h3>Take the first step on your journey to becoming a part of Tea Snow’s Family</h3>
                                </div>
                                <div class="franchise">
                                    <h2>Fill in the franchisee information</h2>
                                    <form action="">
                                        <div class="s-franchise-form">
                                            <label>Name</label>
                                            <input type="text">
                                        </div>
                                        <div class="s-franchise-form">
                                            <label>Date of birth</label>
                                            <input type="date">
                                        </div>
                                        <div class="s-franchise-form">
                                            <label>Email</label>
                                            <input type="email">
                                        </div>
                                        <div class="s-franchise-form">
                                            <label>Phone</label>
                                            <input type="text">
                                        </div>
                                        <div class="s-franchise-form">
                                            <label>Address</label>
                                            <input type="text">
                                        </div>
                                        <div class="s-franchise-form">
                                            <label>Franchisee Type</label>
                                            <select class="custom-select">
                                                <option selected disabled>-- please choose --</option>
                                                <option value="">Option 1</option>
                                                <option value="">Option 1</option>
                                                <option value="">Option 1</option>
                                            </select>
                                        </div>
                                        <div class="s-franchise-form">
                                            <label>Store Address</label>
                                            <div class="form-row">
                                                <div class="col-md-6">
                                                    <select class="custom-select">
                                                        <option value="">Option 1</option>
                                                        <option value="">Option 1</option>
                                                        <option value="">Option 1</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <select class="custom-select">
                                                        <option value="">Option 1</option>
                                                        <option value="">Option 1</option>
                                                        <option value="">Option 1</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <input type="text" placeholder="Address">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="s-franchise-form">
                                            <label>Other</label>
                                            <input type="text">
                                        </div>
                                        <div class="s-franchise-form">
                                            <img width="300" src="assets/img/recap.png" alt="">
                                        </div>
                                        <div class="s-franchise-form">
                                            <button type="submit"><img src="assets/img/submit.png" alt=""></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php include('footer.php'); ?>